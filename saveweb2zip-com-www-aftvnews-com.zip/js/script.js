jQuery(document).ready(function(){
	//Toggle buttons to show hidden div. Store div id in links "toggle" attribute
	jQuery(".toggle").click(function(){
		jQuery("#"+jQuery(this).attr("toggle")).slideToggle();
		jQuery(this).hide();
	});
	
});