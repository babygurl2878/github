jQuery(document).ready(function ($) {
	jQuery(".rtabs-tab").click(function() {rtabsClick(jQuery(this).attr("href").substring(1))});
	
	var rtabshash = window.location.hash.substring(1);
	//console.log("hash is: "+rtabshash);
	if(rtabshash != '') rtabsClick(rtabshash);
});

function rtabsClick(tab){
	console.log("rtabsClick var is: "+tab);
/*	if(typeof ths == "string"){
		console.log("ths string is: "+ths);
		ths = jQuery("#rtabs-"+ths);
	}*/
	//var tab = ths;//jQuery(ths).attr("href").substring(1);
	
	//UPDATE TAB CLASS
	jQuery('.rtabs-tab').removeClass('selected'); 
	jQuery("#rtabs-tab-"+tab).addClass('selected');
	
	//SHOW SECTION
	if(tab=="all"){
		jQuery(".rtabs-section").show();
	}else{
		jQuery(".rtabs-section").hide();
		jQuery("#rtabs-section-"+tab).show();
	}
}